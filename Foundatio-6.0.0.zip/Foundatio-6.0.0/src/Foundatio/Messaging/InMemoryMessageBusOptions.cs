namespace Foundatio.Messaging {
    public class InMemoryMessageBusOptions : MessageBusOptionsBase { }
}