namespace Foundatio.Messaging {
    public class MessageBusData {
        public string Type { get; set; }
        public string Data { get; set; }
    }
}