﻿namespace Foundatio.Metrics {
    public class InMemoryMetricsClientOptions : MetricsClientOptionsBase { }
}