using System;

namespace Foundatio.Caching {
    public class InMemoryCacheClientOptions : CacheClientOptionsBase {}
}