using System;

namespace Foundatio.Benchmarks.Queues {
    public class QueueItem {
        public int Id { get; set; }
    }
}